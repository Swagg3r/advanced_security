#!/usr/bin/env python

pw = 'aaaaaaaa'
print pw

print chr(ord(pw)+1)
